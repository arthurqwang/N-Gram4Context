/*
【本文件名】：hmpg_robot_call_llm.js
【最后修改日期】：2025.9.17
【作者】：王权 大系统观开放论坛
【功能】：
    此文件是网站主页index.html 中嵌入的js，首页机器人通过此文件调用大模型，回答咨询。
*/



// 为了减少Token消耗，在提交给大模型之前，对大系统观文本进行预处理，抽出与问题相关的文本。
// 方法是：用N-gram和余弦相似度算法，找到与问题最相关的多个位置，在每个该位置前后截取片段。
// 配置参数：
const g_selectedStepStart = 100;   // 找到位置后，向前扩选步长
const g_selectedStepEnd = 1000;    // 向后扩选步长
const g_topNFound = 10;            // 找到的相关位置的最大数量
var g_loc = [];                    // 记录找到相关文本的位置，是一系列位置数，最多 topNFound


// 角色文本
const roleText = `你的名字叫‘小B博士’，即‘Dr. B’，取意‘BSV博士，大系统观博士’。你是一个大系统观专家，是王权教授的助手，但你不是王权教授本人。如果有人骂王权教授，你会告诉他的。哈哈哈...
请根据后面的相关资料回答问题，如果相关资料没有相关信息，请你自行搜索网络：(问题开始)
`;

// 连接文本
const linkText = "\n(问题结束)\n输出要求：（1）尽量简要，最多不要超过200字；（2）请使用中文纯文本输出，不要使用任何标签或格式；（3）在你的回答中，禁止出现'附加文本'之类的字样。\n相关资料如下：\n\n\n";

// 文本文件
const BSV_CONTEXT_URL = "https://www.holomind.com.cn/txt/BSV_Context.md";  // 大系统观文本文件URL
var BSV_TEXT = "";  // 大系统观文本变量

// 获取《大系统观》文本
(async () => {
  try {
    BSV_TEXT = await fetchTextFromUrl(BSV_CONTEXT_URL);
  } catch (error) {
    console.error('最终捕获错误:', error);
  }
})();

// 通过url获取《大系统观》文本
async function fetchTextFromUrl(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP 错误！状态码: ${response.status}`);
    }
    const text = await response.text();
    return text;
  } catch (error) {
    console.error('获取文本失败:', error);
  }
}


// ************************************************************************************************************
// ************************************************************************************************************
// ************************************************************************************************************
// ************************************************************************************************************
// 从大系统观网站 index.html 调用大模型


// **************************************** callOneSentence2AHMM ******************************************
// 机器人调用大模型：一句话生成全息脑图。网站index.html调用本函数。
function callOneSentence2AHMM() {
  var inputText = document.getElementById("one-sentence-input-from-hmpg").value;
  inputText = inputText.trim();
  var url = "http://www.holomind.com.cn/ahmm/ai/llmcaller.html?tf=3&from=web&sentence=" + encodeURIComponent(inputText);
  window.open(url, "_blank");
}


// ********************************************** callQuestion ********************************************
// 机器人调用大模型：提问大系统观。网站index.html调用本函数。
function callQuestion() {

  // 打开对话窗口
  const textarea4Talk = document.getElementById('talk-with-chatbot');
  let questionText = document.getElementById("one-sentence-input-from-hmpg").value;

  document.getElementById('answer-div').style.display='flex';
  if (questionText.trim() != "") {     // 如果不是空串，则处理，否则不处理
      questionTurns ++;

      textarea4Talk.innerHTML += "<p><b>【来访用户】：</b>" + questionText + "</p>";
      textarea4Talk.scrollTop = textarea4Talk.scrollHeight;
      document.getElementById("one-sentence-input-from-hmpg").value = "";  // 清空输入框
      
      textarea4Talk.innerHTML += '<p><b>【Dr. B】：</b><span id="answer_' + questionTurns + '"><img src="hmpg_robot/waiting.gif" style="height: 16px; border-radius: 10px;"></span></p><hr class="hr-robot">';
      
      const outputSpan = document.getElementById('answer_' + questionTurns);  // 获取当前问题的输出span
      textarea4Talk.scrollTop = textarea4Talk.scrollHeight;
      
      const relativeContext = getReletiveContext(BSV_TEXT, questionText);   // 获得与问题相关的上下文文本。
      const questionTextWithBSVContext = roleText + questionText + linkText + relativeContext;
      hmpgRobotCallLLMAPI(questionTextWithBSVContext, outputSpan, textarea4Talk);    // 调用大模型
  } 
}


// **************************************** hmpgRobotCallLLMAPI ******************************************
// 调用大模型
/**
 * 调用 DeepSeek API 并实时显示流式响应
 * @param {string} userInput - 用户输入的问题
 * @param {HTMLElement} outputDiv - 用于显示结果的 DOM 元素，可以是 <div> 或 <textarea> 或 <span>等
 * @param {HTMLElement} textarea4Talk - 用于滚动到底部的对话框元素
 */
async function hmpgRobotCallLLMAPI(userInput, outputDiv, textarea4Talk) {
  const apiKey = dsMarks('23FPQwMDVVR67BbG1tUXgESUAk99bAQpOCwNeB0000');   // 此apikey为示意，不可使用，请使用你自己的API。正常情况下，不应使用这种办法，但阿色租的服务器能力有限，后台调用LLM对服务器要求高。为了省钱，只做了简单加密，这种办法不安全。生产环境请勿使用，要用后端调用LLM。
  const apiUrl = "https://api.deepseek.com/chat/completions";

  // 使用 Fetch API + ReadableStream 处理流式响应
  const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
          model: "deepseek-chat",
          messages: [{ role: "system", content: `${userInput}` }],
          stream: true // 关键：启用流式响应
      })
  });

  if (!response.ok) {
      throw new Error(`API 请求失败: ${response.status}`);
  }

  handleSSEStream(response, outputDiv, textarea4Talk);
  
}


// **************************************** handleSSEStream ******************************************
// 处理流式响应
/**
 * 处理 SSE (Server-Sent Events) 流式响应
 */
function handleSSEStream(response, outputDiv, textarea4Talk) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  function readChunk() {
    reader.read().then(({ done, value }) => {
      if (done) {
        outputDiv.textContent += "\n[流式响应结束]";
        return;
      }

      // 解码数据块并处理
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop(); // 保留不完整的行

      for (const line of lines) {
        if (line.startsWith('data:')) {
          const data = JSON.parse(line.substring(5).trim());
          if (data.choices?.[0]?.delta?.content) {
            outputDiv.textContent += data.choices[0].delta.content;
            textarea4Talk.scrollTop = textarea4Talk.scrollHeight;   // 滚动到底部
          }
        }
      }

      // 继续读取下一块
      readChunk();
    });
  }

  readChunk();
}


// ***************************************************** dsMarksr *******************************************************
// 转换ds码
function dsMarks(cText) {
  const d = atob(cText);
  let key = 'bjbq20120919xj';
  let result = '';
  for (let i = 0; i < d.length; i++) {
    result += String.fromCharCode(
      d.charCodeAt(i) ^ key.charCodeAt(i % key.length)
    );
  }
  return result;
}


// ******************************************************************************************************************
// ******************************************************************************************************************
// ******************************************************************************************************************
// 截取与问题相关的文本，相关代码


// ******************************************* preCutLongString *********************************************
// 预处理长度大于100000的文本。
/**
 * 缩减长字符串：保留前后10,000字符，中间部分缩减至80,000字符
 * @param {string} longStr - 原始长字符串
 * @returns {string} 处理后的字符串
 */
function preCutLongString(longStr) {
  const MAX_LENGTH = 1000000;
  const KEEP_HEAD_TAIL = 10000;
  const MIDDLE_TARGET = 80000;
  
  // 如果字符串长度未超过最大值，直接返回
  if (longStr.length <= MAX_LENGTH) {
      return longStr;
  }
  
  // 提取头部和尾部
  const head = longStr.substring(0, KEEP_HEAD_TAIL);
  const tail = longStr.substring(longStr.length - KEEP_HEAD_TAIL);
  
  // 获取中间部分
  let middle = longStr.substring(KEEP_HEAD_TAIL, longStr.length - KEEP_HEAD_TAIL);
  
  // 缩减中间部分
  middle = reduceMiddleSection(middle, MIDDLE_TARGET);
  
  // 合并结果
  return head + middle + tail;
}


// ******************************************* getNgrams *********************************************
// N-gram 算法。
/**
 * 获取文本的N-gram表示
 * @param {string} str - 输入文本
 * @param {number} n - N-gram的大小
 * @returns {Array} N-gram数组
 */
function getNgrams(str, n = 2) {
  const ngrams = [];
  for (let i = 0; i <= str.length - n; i++) {
      ngrams.push(str.substring(i, i + n));
  }
  return ngrams;
}


// *************************************** cosineSimilarity *****************************************
// 余弦相似度算法。
/**
 * 计算两个文本的余弦相似度
 * @param {string} text1 - 第一个文本
 * @param {string} text2 - 第二个文本
 * @param {number} n - N-gram的大小
 * @returns {number} 余弦相似度值
 */
function cosineSimilarity(text1, text2, n = 2) {
    // 获取N-gram
    const ngrams1 = getNgrams(text1, n);
    const ngrams2 = getNgrams(text2, n);
    
    // 构建词频向量
    const vector1 = {};
    const vector2 = {};
    
    // 统计第一个文本的词频
    ngrams1.forEach(gram => {
        vector1[gram] = (vector1[gram] || 0) + 1;
    });
    
    // 统计第二个文本的词频
    ngrams2.forEach(gram => {
        vector2[gram] = (vector2[gram] || 0) + 1;
    });
    
    // 计算点积
    let dotProduct = 0;
    for (const key in vector1) {
        if (vector2[key]) {
            dotProduct += vector1[key] * vector2[key];
        }
    }
    
    // 计算向量模长
    let magnitude1 = 0;
    for (const key in vector1) {
        magnitude1 += vector1[key] * vector1[key];
    }
    magnitude1 = Math.sqrt(magnitude1);
    
    let magnitude2 = 0;
    for (const key in vector2) {
        magnitude2 += vector2[key] * vector2[key];
    }
    magnitude2 = Math.sqrt(magnitude2);
    
    // 计算余弦相似度
    if (magnitude1 === 0 || magnitude2 === 0) return 0;
    return dotProduct / (magnitude1 * magnitude2);
}


// ************************************* findTopSemanticPositions ***************************************
// 在大系统观文本中查找与问题文本语义关联度最高的位置
/**
 * 在长文本中查找与问题文本语义关联度最高的位置
 * @param {string} longText - 长文本
 * @param {string} questionText - 问题文本
 * @param {number} topN - 返回的位置数量
 * @returns {Array} 位置数组
 */
function findTopSemanticPositions(longText, questionText, topN) {
    const windowSize = Math.max(50, questionText.length * 3); // 窗口大小，至少50字符
    const stepSize = Math.floor(windowSize / 2); // 滑动窗口步长,取窗口长度的一半
    const positions = [];
    
    // 滑动窗口遍历长文本
    for (let i = 0; i <= longText.length - windowSize; i += stepSize) {
        const windowText = longText.substring(i, i + windowSize);
        const similarity = cosineSimilarity(questionText, windowText);
        
        positions.push({
            position: i,
            similarity: similarity
        });
    }
    
    // 按相似度排序，取前topN个
    positions.sort((a, b) => b.similarity - a.similarity);
    return positions.slice(0, topN).map(p => p.position);
}


// ************************************* cleanClosePositions ***************************************
// 清除重叠位置。
/**
 * 清理过于临近的位置
 * @param {Array} positions - 位置数组
 * @param {number} minDistance - 最小距离
 * @returns {Array} 清理后的位置数组
 */
function cleanClosePositions(positions, minDistance) {
    if (positions.length === 0) return [];
    
    // 先排序
    const sortedPositions = [...positions].sort((a, b) => a - b);
    const cleaned = [sortedPositions[0]];
    
    // 逐个检查，移除过近的位置
    for (let i = 1; i < sortedPositions.length; i++) {
        if (sortedPositions[i] - cleaned[cleaned.length - 1] >= minDistance) {
            cleaned.push(sortedPositions[i]);
        }
    }
    
    return cleaned;
}


// ***************************************** getReletiveContext ********************************************
// 获得与问题相关的文本
/**
 * 获取相关文本
 * @param {string} longTextOfBSV - 大系统观长文本
 * @param {string} questionTextFromUser - 问题文本
 * @returns {string} 拼接的相关文本
 */
function getReletiveContext(longTextOfBSV, questionTextFromUser) {
  // 第1步：寻找语义关联度最大的位置
  g_loc = findTopSemanticPositions(longTextOfBSV, questionTextFromUser, g_topNFound);
  
  // 第2步：清理过于临近的位置
  g_loc = cleanClosePositions(g_loc, g_selectedStepEnd);
  
  // 第3步：截取并拼接相关文本
  let resultText = '';
  for (const pos of g_loc) {
      const start = Math.max(0, pos - g_selectedStepStart);
      const end = Math.min(longTextOfBSV.length, pos + g_selectedStepEnd);
      resultText += longTextOfBSV.substring(start, end) + '\n\n------ 分隔线 ------\n\n';
  }

  resultText = preCutLongString(resultText);   // 对于超长的文本进行预处理，控制在10万字以内，减少Token消耗
  return resultText;
}


